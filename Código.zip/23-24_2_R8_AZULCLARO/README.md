# Reto_08 AZUL CLARO

Durante este reto se han trabajado los siguientes objetivos:

1. ### **Diseño y despliegue de una arquitectura de Big Data**
   Que permita la ingesta, manipulación, análisis y visualización de datos en tiempo real provenientes de dispositivos de una planta industrial utilizando el stack de Elastic.

2. ### **Optimización de la eficiencia energética**
   De cuatro compresores industriales a través del desarrollo e implementación de un algoritmo genético.

3. ### **Almacenar los resultados en la base de datos de MongoDB**
   Visualizando el rendimiento y las recomendaciones en un cuadro de mandos en Dash.

4. ### **Realizar consultas**
   Sobre los datos de los compresores a través del broker MQTT de Mosquitto y **visualizarlos** en tiempo real en un dashboard de Kibana.

En lineas generales, se busca crear una infraestructura BigData para buscar posibles anomalias en los datos, asi como realizar un Algoritmo Genetico a fin de reducir el consumo de energia de los compresores, regulando la frecuencia.

## EJECUCIÓN DE PROYECTO

#### A: Limpieza y Preprocesamiento de los Datos + Anomalías
Este proceso se ha de ejecutar en el orden estipulado en los scripts:
- A_01
- A_02
- A_03
- ...

#### DM: Optimización de los Compresores
Optimización de la eficiencia energética de cuatro compresores industriales a través del desarrollo e implementación de un algoritmo genético.

#### DS: Sistema Publisher/Subscriber
Implementación de un sistema Publisher/Subscriber para la gestión y distribución de datos.

#### V_DASH: Visualización del Algoritmo Respectivo a los Compresores
Visualización del rendimiento y las recomendaciones en un cuadro de mandos en Dash.

#### P: Consultas en MongoDB
Realización de consultas sobre los datos de los compresores y almacenamiento de los resultados en la base de datos de MongoDB.

#### BD: Arquitectura Big Data
Convertir las direcciones IP en localizaciones para luego visualizar en kibana + telebot

## ACLARACIONES 
Los csv de los compresores estan en una carpeta llamada *"OPTIMIZACION"* dentro de la carpeta de *"DATOS/ORIGINALES"*, por lo que quizas haya que cambiar la ruta, dependiendo del nombre de la carpeta y donde esté ubicada.


