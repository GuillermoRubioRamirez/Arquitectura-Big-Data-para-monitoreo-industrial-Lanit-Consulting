import paho.mqtt.client as paho
import logging
from DS_functions import *

logging.basicConfig(level=logging.DEBUG, format='%(asctime)s > %(name)s > %(levelname)s: %(message)s')

broker = "localhost"

publisher_2 = paho.Client(paho.CallbackAPIVersion.VERSION2,"P2", clean_session=True)

logging.debug(f'Connecting to broker {broker}')
publisher_2.connect(broker)

topic_2 = 'topic_queries'

while True:

    print("\nConsultas disponibles:\n \n 1- /estadisticas_por_compresor \n 2- /maximo_registrado variable \n"
          " 3- /minimo_registrado variable \n"  " 4- /frecuencias_problematicas \n")
        

    query = input(
                '\nSeleccione una consulta: ')

    message = query

    publisher_2.publish(topic_2, message, qos=1)
    
    print("\nEnviando a topic_queries: " + message)