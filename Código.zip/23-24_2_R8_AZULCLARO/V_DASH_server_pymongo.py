import os
import pymongo
from dash import dash_table
import json
from plotly.subplots import make_subplots
import plotly.express as px
import numpy as np
import pandas as pd
from dash.dependencies import Input, Output, State
from dash import html, dcc
import dash_bootstrap_components as dbc
import dash

from DM_funciones import *


cliente = pymongo.MongoClient(
    "mongodb://localhost:27017/")  # Establecemos la conexion
bd = cliente['Reto_08']
coleccion = bd['optimizacion']

# leer csvs
mypath = 'DATOS/ORIGINALES/OPTIMIZACION'
csvs = os.listdir(mypath)

dataframes = {}

for archivo in csvs:
    ruta_completa = os.path.join(mypath, archivo)
    nombre_df = os.path.splitext(archivo)[0]

    dataframes[nombre_df] = pd.read_csv(ruta_completa)


# todas las presiones y temperaturas para luego elegir al azar.
presion = []
temperatura = []
frecuencia = []
potencia = []
for c, df in dataframes.items():
    presion.extend(df.Presion)
    temperatura.extend(df.Temperatura)
    frecuencia.extend(df.Frecuencia)
    potencia.extend(df.Potencia_Medida)


# mejores argumentos para los parametros de la funcion pygad
with open('mejores_argumentos.json', 'r') as file:
    mejores_argumentos = json.load(file)

app = dash.Dash(external_stylesheets=[
                dbc.themes.FLATLY, 'https://codepen.io/chriddyp/pen/dZVMbK.css'])

frecuencias_iniciales = [50, 50, 50, 50]
fig_inicial = px.bar(x=dataframes.keys(), y=frecuencias_iniciales)
fig_inicial.update_layout(yaxis=dict(range=[0, 100]))
fig_inicial.update_xaxes(title_text='')
fig_inicial.update_yaxes(title_text='Frecuencia de los compresores')

df_mas_uno_inicial = list(dataframes.keys())
df_mas_uno_inicial.append(df_mas_uno_inicial[0])

frecuen_inicial = list(frecuencias_iniciales)
frecuen_inicial.append(frecuen_inicial[0])

docs = coleccion.find()
docs_df = pd.DataFrame(list(docs))
docs_df[['comp_A', 'comp_B', 'comp_C', 'comp_D']] = pd.DataFrame(
    docs_df['frecuencias'].to_list(), index=docs_df.index)
docs_df.drop(columns=['_id', 'frecuencias'], inplace=True)

fig_inicial2 = go.Figure(data=go.Scatterpolar(
    r=frecuen_inicial,
    theta=df_mas_uno_inicial,
    mode='lines',
    fill='toself'
))
fig_inicial2.update_layout(
    polar=dict(
        radialaxis=dict(
            visible=True,
            range=[0, 100]
        )
    ),
    showlegend=False
)

df_1 = dataframes.keys()
l = [i for i in df_1]

df = pd.concat([dataframes[v] for v in l])

# Add a 'source' column to differentiate the data
df['source'] = pd.concat([pd.Series([v]*len(dataframes[v])) for v in l])

# Create a scatter plot
fig_inicial_3 = px.scatter(
    df, x='Frecuencia', y='Potencia_Medida', color='source')
fig_inicial_3.update_legends(title='Compresores')


###
sidebar = html.Div(
    [
        html.Div([html.H5('Optimización',
                          style={'margin-top': '12px', 'margin-left': '24px', 'text-align': 'center'})],
                 style={"height": "5vh",
                        'background-color': '#343a40',
                        'color': 'white'},
                 ),

        html.Div([
            html.Label('Presión',
                       style={'margin-top': '8px', 'margin-bottom': '4px'}),
            dcc.Input(placeholder='Presion', type='number',
                      id='presion', min=min(presion), max=max(presion), step=0.00000001, className='four columns', debounce=True,
                      style={'width': '320px'}
                      ),
            html.Label('Temperatura',
                       style={'margin-top': '16px',
                              'margin-bottom': '4px'}),
            dcc.Input(placeholder='Temperatura', type='number',
                      id='temperatura', min=min(temperatura), max=max(temperatura), className='four columns', debounce=True,
                      style={'width': '320px'}
                      ),
            html.Label('Volumen de Aire(Caudal)',
                       style={'margin-top': '16px',
                              'margin-bottom': '4px'}),
            dcc.Input(placeholder='Volumen', type='number', id='volumen_aire',
                      min=50, max=350, step=1, className='four columns', debounce=True,
                      style={
                                  'width': '320px'}
                      ),
            html.Button(id='button', children='Optimizar',
                        style={'margin-top': '16px',
                               'background-color': '#343a40',
                               'color': 'white'}),
            html.Hr()
        ],
            style={'height': '50vh', 'margin': '8px'})
    ]
)

alerta = dbc.Alert([html.H4('Vaya!', className='alert-heading'),
                   html.P(
                       'Parece que no se puede optimizar con esos valores, intenta con otros'),
                   html.Hr(),
                   html.P('Prueba con un volumen de aire inferior')],
                   color='danger'
                   )
alerta_bien = dbc.Alert(html.H4('Optimizado!', className='alert-heading'),
                        color='success')
content = html.Div([
    dbc.Row([
        dbc.Col([
            html.P(id='title',
                   className='font-weight-bold'),
            dcc.Graph(id="bar-graf", figure=fig_inicial,
                      className='bg-light')

        ]),
        dbc.Col([
            html.P(id='title_2',
                   className='font-weight-bold'),
            dcc.Graph(id="polar-graf", figure=fig_inicial2,
                      className='bg-light')
        ])
    ]),
    html.Div(id='alerta')
]
)

tabla = html.Div([dash_table.DataTable(data=docs_df.to_dict('records'),
                                       columns=[{'name': i, 'id': i}
                                                for i in docs_df.columns],
                                       id='tbl',
                                       style_header={
                                           'background-color': '#343a40',
                                           'color': 'white'},
                                       style_data_conditional=[{
                                           'if': {'row_index': 'odd'},
                                           'backgroundColor': 'rgb(248, 248, 248)'
                                       }])
                  ])


primera_fila = html.Div([
    html.Div(className='one columns'),
    html.Div([
        html.H5('Frecuencia', style={'color': 'white',
                                     'text-align': 'center'}),
    ], className='four columns', style={'background-color': '#343a40',
                                        'border-radius': '10px'}),

    html.Div(className='two columns'),
    html.Div([
        html.H5('Potencia', style={'color': 'white',
                                   'text-align': 'center'}),
    ], className='four columns', style={'background-color': '#343a40',
                                        'border-radius': '10px'}),


], className='row')

segunda_fila = html.Div([
    dcc.RangeSlider(id='freq-rang', min=0, max=np.max(frecuencia), tooltip={'always_visible': True},
                    value=[0, np.max(frecuencia)], className='six columns'),
    dcc.RangeSlider(id='pot-rang', min=0, max=np.max(potencia), tooltip={'always_visible': True},
                    value=[0, np.max(potencia)], className='six columns')
])
tercera_fila = html.Div([
    html.Div(className='four columns'),
    html.Div([
        html.Div([html.H5('Compresores',
                          style={'color': 'white'})
                  ],
                 style={'background-color': '#343a40',
                        'border-radius': '10px'}),
        dcc.Checklist(id='comp-check',
                      options=[{'label': i, 'value': i} for i in df_1],
                      value=[i for i in df_1])
    ], style={'text-align': 'center',
              'border-radius': '10px'},
        className='four columns'
    ),
    html.Div(className='four columns')
], className='row')

datos_compresores = html.Div([
    html.Br(),
    primera_fila,
    html.Br(),
    segunda_fila,
    html.Br(),
    html.Br(),
    tercera_fila,
    dcc.Graph(id='graf-disp', figure=fig_inicial_3)

])


app.layout = html.Div([
    html.H1('Dash Compresores',
            style={'text-align': 'center'}),
    dcc.Tabs([
        dcc.Tab(label='Optimización de la Frecuencia de los compresores', children=[
            dbc.Container(
                [
                    dbc.Row(
                        [
                            dbc.Col(sidebar, width=3, className='bg-light'),
                            dbc.Col(content, width=9)
                        ]
                    ),
                ],
                fluid=True
            )]),
        dcc.Tab(label='Base de Datos', children=[html.Div(tabla)]),
        dcc.Tab(label='Compresores', children=[html.Div(datos_compresores)]),
    ])
]
)


@ app.callback([Output(component_id='bar-graf', component_property='figure'),
                Output(component_id='polar-graf', component_property='figure'),
                Output(component_id='alerta',
                       component_property='children'),
                Output(component_id='tbl', component_property='data')],
               [Input(component_id='button', component_property='n_clicks')],
               [State(component_id='presion', component_property='value'),
               State(component_id='temperatura', component_property='value'),
               State(component_id='volumen_aire', component_property='value')]
               )
def fun(n_clicks, presion, temperatura, volumen_aire):
    if n_clicks is None:
        return dash.no_update, dash.no_update, dash.no_update, docs_df.to_dict('records')
    doc = coleccion.find_one(
        {'presion': presion, 'temperatura': temperatura, 'volumen_aire': volumen_aire})
    if doc is not None:
        frecuencias = doc['frecuencias']
        frecuencias =[v for i,v in frecuencias.items()]
        fitness = doc['fitness']
    else:
        frecuencias, fitness = algoritmo_genetico_py(best_m_t=mejores_argumentos['mutation_operator'],
                                                  best_m_g=mejores_argumentos['mutation_percent_genes'],
                                                  best_m_p=mejores_argumentos['mutation_probability'],
                                                  best_c_t=mejores_argumentos['crossover_operator'],
                                                  best_p_t=mejores_argumentos['selection_operator'],
                                                  dataframes=dataframes,
                                                  presion=presion,
                                                  temperatura=temperatura,
                                                  v=volumen_aire)
        if fitness <= -1e10:
            error_figure = make_subplots()
            return error_figure, error_figure, alerta, docs_df.to_dict('records')
        else:
            frecuencias_dict = {key:value for key,value in zip(dataframes.keys(),frecuencias)}
            doc = {
                'presion': presion,
                'temperatura': temperatura,
                'volumen_aire': volumen_aire,
                'frecuencias':frecuencias_dict ,
                'fitness': fitness
            }
            coleccion.insert_one(doc)

    fig = px.bar(x=dataframes.keys(), y=frecuencias)
    fig.update_layout(yaxis=dict(range=[0, 100]))
    fig.update_xaxes(title_text='')
    fig.update_yaxes(title_text='Frecuencia de los compresores')

    df_mas_uno_2 = list(dataframes.keys())
    df_mas_uno_2.append(df_mas_uno_2[0])

    frecuen_2 = list(frecuencias)
    frecuen_2.append(frecuen_2[0])
    fig_2 = go.Figure(data=go.Scatterpolar(
        r=frecuen_2,
        theta=df_mas_uno_2,
        mode='lines',
        fill='toself'
    ))
    fig_2.update_layout(
        polar=dict(
            radialaxis=dict(
                visible=True,
                range=[0, 100]
            )
        ),
        showlegend=False
    )
    d = coleccion.find()
    d_df = pd.DataFrame(list(d))
    d_df[['comp_A', 'comp_B', 'comp_C', 'comp_D']] = pd.DataFrame(
        d_df['frecuencias'].to_list(), index=d_df.index)
    d_df.drop(columns=['_id', 'frecuencias'], inplace=True)
    print(frecuencias, fitness)
    return fig, fig_2, alerta_bien, d_df.to_dict('records')


@app.callback(Output(component_id='graf-disp', component_property='figure'),
              [Input(component_id='freq-rang', component_property='value'),
               Input(component_id='pot-rang', component_property='value'),
               Input(component_id='comp-check', component_property='value')])
def update_graph(freq_rang, pot_rang, comp_check):
    df = pd.concat([dataframes[v] for v in l])
    df['source'] = pd.concat([pd.Series([v]*len(dataframes[v])) for v in l])
    df_modificado = df[(df['Frecuencia'] > freq_rang[0]) & (df['Frecuencia'] < freq_rang[1]) & (
        df['Potencia_Medida'] > pot_rang[0]) & (df['Potencia_Medida'] < pot_rang[1]) & (df['source'].isin(comp_check))]
    fig = px.scatter(
        df_modificado, x='Frecuencia', y='Potencia_Medida', color='source')
    fig.update_legends(title='compresores')
    return fig


if __name__ == '__main__':
    app.run_server(debug=True)
