import json
import numpy as np
import pandas as pd
import paho.mqtt.client as paho
from datetime import datetime, timedelta
import logging
from elasticsearch import Elasticsearch

class Handler:
    
    def __init__(self):
        self.all_data = []
        self.frecuencias_problematicas = []
    def on_message(self, client, userdata, message):
        all_data = self.all_data
        frecuencias_problematicas = self.frecuencias_problematicas

        if message.topic == "topic_data":
            data = json.loads(message.payload.decode("utf-8"))
            if data not in all_data:
                all_data.append(data)
            
            prob = deteccion_problema_frecuencia(data)
            if prob != None:
                frecuencias_problematicas.append(prob)

        if message.topic == 'topic_queries':
            consultas(message.payload.decode('utf-8'), all_data, frecuencias_problematicas)

def estadisticas_por_compresor(df):
    compresores = df['Compresor'].unique()
    df[['Presion','Temperatura','Frecuencia','Potencia_Medida']] = df[['Presion','Temperatura','Frecuencia','Potencia_Medida']].astype(float)

    aux = []

    for compresor in compresores:
        result = df[df["Compresor"] == compresor].copy()
        presion = result['Presion'].mean()
        temp = result['Temperatura'].mean()
        freq = result['Frecuencia'].mean()
        pot = result['Potencia_Medida'].mean()
        cant = len(result)
        aux.append({'Compresor':compresor,'Media_presion':presion,'Media_temperatura':temp,'Media_frecuencia':freq,'Media_potencia':pot,'numero_de_datos':cant})
    return aux

def numero_datos(df):
    aux = len(df)
    return aux

def deteccion_problema_frecuencia(data):
    if (data['Frecuencia'] > 89) | (data['Frecuencia'] < 1):
        logging.basicConfig(level=logging.DEBUG, format='%(asctime)s > %(name)s > %(levelname)s: %(message)s')
        broker = "localhost"
        publisher_3 = paho.Client(paho.CallbackAPIVersion.VERSION2,"P3", clean_session=True)
        publisher_3.connect(broker)
        publisher_3.publish("frecuencias_problematicas", json.dumps(data).encode("utf-8"))
        publisher_3.disconnect()

        return data
    else: 
        return None

def consultas(message, all_data, frecuencias_problematicas):
    if np.size(all_data) == 0:
        print("No hay datos guardados")
    else:
        if message == '/estadisticas_por_compresor': #Media de presion, temperatura,frecuencia y potencia medida por compresor
            df_all_data = pd.DataFrame(all_data)
            df_all_data[['Presion','Temperatura','Frecuencia','Potencia_Medida']] = df_all_data[['Presion','Temperatura','Frecuencia','Potencia_Medida']].astype(float)
            aux = estadisticas_por_compresor(df_all_data)
            df = pd.DataFrame(aux)
            client = conexion_elastic(password="R=2T4oJMRO_kes92KX4Y",ca_certs="/home/guillermo/elasticsearch-8.4.3/config/certs/http_ca.crt")
            indexar_datos_elastic(client,df,index='estadisticas_generales')
            print("\nEstas son las estadisticas por compresores:")
            print(df)

        
        if message.split(' ')[0] == '/minimo_registrado': #Minimo registrado de la variable indicada
            df_all_data = pd.DataFrame(all_data)
            if message.split(' ')[1] in df_all_data.columns:
                variable = message.split(' ')[1]
                var = df_all_data[df_all_data[variable] == df_all_data[variable].min()][variable].iloc[0]
                comp = df_all_data[df_all_data[variable] == df_all_data[variable].min()]['Compresor'].iloc[0]
                print(f"\n El minimo registrado de la variable {variable} es {var} y se registro en el {comp}")
            else:
                print('\n La variable indicada no es una variable del df. Las variables son las siguientes: Presion, Temperatura, Potencia_Medida')

        
        if message.split(' ')[0] == '/maximo_registrado': #Maximo registrado de la variable indicada
            df_all_data = pd.DataFrame(all_data)
            if message.split(' ')[1] in df_all_data.columns:
                variable = message.split(' ')[1]
                var = df_all_data[df_all_data[variable] == df_all_data[variable].min()][variable].iloc[0]
                comp = df_all_data[df_all_data[variable] == df_all_data[variable].max()]['Compresor'].iloc[0]
                print(f"\n El maximo registrado de la variable {variable} es {var} y se registro en el {comp}")
            else:
                print('\n La variable indicada no es una variable del df. Las variables son las siguientes: Presion, Temperatura, Potencia_Medida')
            
        if message == '/frecuencias_problematicas':
            if np.size(frecuencias_problematicas) != 0:
                df_frecuencias_problematicas = pd.DataFrame(frecuencias_problematicas)
                df_frecuencias_problematicas[['Presion','Temperatura','Frecuencia','Potencia_Medida']] = df_frecuencias_problematicas[['Presion','Temperatura','Frecuencia','Potencia_Medida']].astype(float)
                aux = estadisticas_por_compresor(df_frecuencias_problematicas)
                df = pd.DataFrame(aux)
                client = conexion_elastic(password="R=2T4oJMRO_kes92KX4Y",ca_certs="/home/guillermo/elasticsearch-8.4.3/config/certs/http_ca.crt")
                indexar_datos_elastic(client,df,index='frecuencias_problematicas')
                print("\nLas frecuencias problematicas son frecuencias que oscilan entre 0 y 10 o 90 y 100.")
                print("\nEstas son las estadisticas por compresor solamente teniendo en cuenta esas frecuencias:")
                print(df)

def on_connect(client, userdata, flags, rc,extra_arg=None):
    logging.debug(f'Connected with result code {rc}')
    logging.debug("Subscribing")

def conexion_elastic(password,ca_certs):
    client = Elasticsearch(
        "https://localhost:9200",
        ca_certs=ca_certs,
        basic_auth=("elastic",password)
    )
    return client

def indexar_datos_elastic(client,df,index):
    ID = 0
    for i in range(len(df)):
        data = dict(df.iloc[i])
        doc = {
            'Compresor':data['Compresor'],
            'Media_presion':float(data['Media_presion']),
            'Media_temperatura':float(data['Media_temperatura']),
            'Media_frecuencia':float(data['Media_frecuencia']),
            'Media_potencia':float(data['Media_potencia']),
            'Numero_de_datos':int(data['numero_de_datos'])
            }
        client.index(index=index,id = ID,document=doc)
        ID += 1

