import pandas as pd
import datetime
import numpy as np
import seaborn as sns
from sklearn.ensemble import RandomForestRegressor
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error, r2_score
from sklearn.model_selection import cross_val_score
from hyperopt import Trials
from hyperopt import fmin, tpe, hp
from sklearn.model_selection import GridSearchCV
from sklearn.linear_model import LinearRegression
import matplotlib.pyplot
import plotly.express as px
import plotly.graph_objects as go
import nbformat
import os
from sklearn.ensemble import AdaBoostRegressor
from sklearn.ensemble import GradientBoostingRegressor
import xgboost as xgb

import joblib
import os
import random

import pygad

from tqdm import tqdm


##### CARGA DE MODELOS #####
def mejores_modelos(modelos_para_probar, dataframes):
    os.makedirs('modelos', exist_ok=True)
    for i, dataframe in dataframes.items():
        # VARIABLES PREDICTORAS
        X = dataframe.drop(columns='Potencia_Medida')
        y = dataframe.Potencia_Medida

        train_x, test_x, train_y, test_y = train_test_split(
            X, y, test_size=0.2, random_state=2)

        # PROBAMOS DIFERENTES MODELOS
        mejor_modelo = None
        mejor_score = -float('inf')
        for modelo in modelos_para_probar:
            regr_model = modelo
            regr_model.fit(train_x, train_y)
            y_pred = regr_model.predict(test_x)
            score = r2_score(test_y, y_pred)
            if score > mejor_score:
                mejor_modelo = modelo
                mejor_score = score
        joblib.dump(mejor_modelo, f'modelos/{i}.pkl')


def carga_modelos():
    modelos = []
    for modelo in os.listdir('modelos'):
        modelos.append(joblib.load(f'modelos/{modelo}'))
    return modelos

def carga_modelos_py():
    modelos = []
    for modelo in os.listdir('Compresores/modelos'):
        modelos.append(joblib.load(f'Compresores/modelos/{modelo}'))
    return modelos
#### PREDICCIONES ####


def predicciones(presion: float, temperatura: float, frecuencia, modelos: list):
    predicciones = []
    for i, v in enumerate(frecuencia):
        data = {
            'Presion': [presion],
            'Temperatura': [temperatura],
            'Frecuencia': [frecuencia[i]]
        }
        # Crear el DataFrame
        df = pd.DataFrame(data)
        predicciones.append(modelos[i].predict(df).item())
    return predicciones


##### GENERACION DE VALORES ALEATORIOS #####

def presion_temperatura_azar(dataframes):
    presion_lista = []
    temperatura_lista = []
    for c, df in dataframes.items():
        presion_lista.extend(df.Presion)
        temperatura_lista.extend(df.Temperatura)
    presion = random.choice(presion_lista)
    temperatura = random.choice(temperatura_lista)
    return presion, temperatura


#### ALGORITMO GENETICO ####
## GENESISIS ##

def genesis(pop_size, n_items):
    population = np.random.uniform(0, 100, size=(pop_size, n_items))
    return population

## ESPCACIO GENETICO ##


def espacio_genetico(dataframes):
    freqs = []
    for i in dataframes.keys():
        freqs.extend(dataframes[i].Frecuencia)

    gene_space = [f for f in freqs if 0 < f < 90]
    return gene_space


### VALORES FIJOS ###

def valores_fijos():
    inputs = np.array([100, 90, 95, 110])/100
    EA = [50, 50, 50, 50]
    return inputs, EA


### PARAMETROS DE BUSQUEDA ###

def parametros_busqueda():
    mutation_types = ['swap', 'scramble', 'inversion', 'random']
    mutation_percent_genes_values = [10, 20, 30, 40, 50]  # Adjust as necessary
    mutation_probability_values = [0.1, 0.2, 0.3]  # Adjust as necessary
    parent_selection_type = ['sss', 'rank', 'tournament', 'random']
    crossover_types = ['single_point', 'two_points', 'uniform']
    return mutation_types, mutation_percent_genes_values, mutation_probability_values, parent_selection_type, crossover_types

## BUSCAR LOS MEJORES PARAMETROS ##


def mejores_parametros(dataframes):
    print("Iniciando fit...")
    modelos_para_probar = [LinearRegression(n_jobs=-1), RandomForestRegressor(
        n_jobs=-1), AdaBoostRegressor(), GradientBoostingRegressor(), xgb.XGBRegressor(n_jobs=-1)]
    print("Modelos para probar definidos.")

    inputs, EA = valores_fijos()
    v = 200
    print(
        f"Valores fijos obtenidos: \nVolumen de aire mínimo: {v}, \n volumenes de aire de cada compresor: {inputs}, \n situacion inicial: {EA}")

    presion, temperatura = presion_temperatura_azar(dataframes)
    print(
        f"Presión y temperatura obtenidas: \npresion: {presion}, \ntemperatura: {temperatura}")

    mejores_modelos(dataframes=dataframes,
                    modelos_para_probar=modelos_para_probar)
    print("Mejores modelos calculados.")

    modelos = carga_modelos()
    print("Modelos cargados.")

    def fitness_func(ga_instance, solution, solution_idx):
        global cambios
        output = np.sum(solution*inputs)
        if (output < v) or any(value > 89 or value < 1 for value in solution):
            fitness = 1e10
        else:
            pred = predicciones(presion, temperatura, solution, modelos)
            fitness = np.sum(pred)
        cambios = 0
        for i, j in enumerate(solution):
            if EA[i] != solution[i]:
                cambios += 1*3

        return -(fitness+cambios)

    print("Función de fitness definida.")

    mutation_types, mutation_percent_genes_values, mutation_probability_values, parent_selection_type, crossover_types = parametros_busqueda()
    print("Parámetros de búsqueda obtenidos.")

    best_m_t = None
    best_m_g = None
    best_m_p = None

    total_iterations = len(mutation_types) * len(mutation_percent_genes_values) * \
        len(mutation_probability_values) * \
        len(parent_selection_type) * len(crossover_types)

    progress_bar = tqdm(total=total_iterations, desc="Progress",
                        bar_format='{l_bar}{bar}| {n_fmt}/{total_fmt}')

    best_fitness = -1e10
    for c_t in crossover_types:
        for p_t in parent_selection_type:
            for m_t in mutation_types:
                for m_g in mutation_percent_genes_values:
                    for m_p in mutation_probability_values:
                        ga_instance = pygad.GA(fitness_func=fitness_func,
                                               num_generations=100,
                                               num_parents_mating=4,
                                               initial_population=genesis(
                                                   10, 4),
                                               num_genes=10,
                                               parent_selection_type=p_t,
                                               crossover_type=c_t,
                                               mutation_type=m_t,
                                               mutation_percent_genes=m_g,  # percentage of 0 to 100 of the genes that mutate
                                               mutation_probability=m_p,  # percentage of 0 to 1 of the mutation occurring
                                               save_solutions=True,
                                               gene_space=espacio_genetico(dataframes))
                        ga_instance.run()
                        progress_bar.update(1)
                        solution, solution_fitness, solution_idx = ga_instance.best_solution(
                            ga_instance.last_generation_fitness)

                    if solution_fitness > best_fitness:
                        best_fitness = solution_fitness
                        best_m_t = m_t
                        best_m_g = m_g
                        best_m_p = m_p
                        best_c_t = c_t
                        best_p_t = p_t
    progress_bar.close()
    print(f'{best_fitness}, {best_m_t}, {best_m_g}, {best_m_p}, {best_c_t}, {best_p_t}')
    return best_fitness, best_m_t, best_m_g, best_m_p, best_c_t, best_p_t, presion, temperatura


def algoritmo_genetico(best_m_t, best_m_g, best_m_p, best_c_t, best_p_t, presion, temperatura, v, dataframes):
    inputs, EA = valores_fijos()
    modelos = carga_modelos()

    def fitness_func(ga_instance, solution, solution_idx):
        global cambios
        output = np.sum(solution*inputs)
        if (output < v) or any(value > 89 or value < 1 for value in solution):
            return -1e10
        else:
            pred = predicciones(presion, temperatura, solution, modelos)
            fitness = np.sum(pred)
        cambios = 0
        for i, j in enumerate(solution):
            if EA[i] != solution[i]:
                cambios += 1*3

        return -(fitness+cambios)
    ga_instance = pygad.GA(fitness_func=fitness_func,
                           num_generations=50,
                           num_parents_mating=4,
                           initial_population=genesis(10, 4),
                           num_genes=50,
                           parent_selection_type=best_p_t,
                           crossover_type=best_c_t,
                           mutation_type=best_m_t,
                           mutation_percent_genes=best_m_g,  # percentage of 0 to 100 of the genes that mutate
                           mutation_probability=best_m_p,  # percentage of 0 to 1 of the mutation occurring
                           save_solutions=True,
                           gene_space=espacio_genetico(dataframes))
    ga_instance.run()
    solution, solution_fitness, solution_idx = ga_instance.best_solution(
        ga_instance.last_generation_fitness)

    return solution, solution_fitness


def algoritmo_genetico_py(best_m_t, best_m_g, best_m_p, best_c_t, best_p_t, presion, temperatura, v, dataframes):
    inputs, EA = valores_fijos()
    modelos = carga_modelos_py()

    def fitness_func(ga_instance, solution, solution_idx):
        global cambios
        output = np.sum(solution*inputs)
        if (output < v) or any(value > 89 or value < 1 for value in solution):
            return -1e10
        else:
            pred = predicciones(presion, temperatura, solution, modelos)
            fitness = np.sum(pred)
        cambios = 0
        for i, j in enumerate(solution):
            if EA[i] != solution[i]:
                cambios += 1*3

        return -(fitness+cambios)
    ga_instance = pygad.GA(fitness_func=fitness_func,
                           num_generations=50,
                           num_parents_mating=4,
                           initial_population=genesis(10, 4),
                           num_genes=50,
                           parent_selection_type=best_p_t,
                           crossover_type=best_c_t,
                           mutation_type=best_m_t,
                           mutation_percent_genes=best_m_g,  # percentage of 0 to 100 of the genes that mutate
                           mutation_probability=best_m_p,  # percentage of 0 to 1 of the mutation occurring
                           save_solutions=True,
                           gene_space=espacio_genetico(dataframes))
    ga_instance.run()
    solution, solution_fitness, solution_idx = ga_instance.best_solution(
        ga_instance.last_generation_fitness)

    return solution, solution_fitness