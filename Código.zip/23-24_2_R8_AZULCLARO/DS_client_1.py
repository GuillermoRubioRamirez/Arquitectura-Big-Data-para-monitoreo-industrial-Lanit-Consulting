from datetime import datetime
from time import sleep
import json
from DS_functions import *
import paho.mqtt.client as paho
import logging
import pandas as pd
import os


### VAMOS A JUNTAR TODOS LOS DATAFRAMES DE LOS COMPRESORES EN UNO MISMO, PARA ELLO, CREAMOS LA COLUMNA "Compresor" PARA DIFERENCIARLOS
mypath = 'DATOS/ORIGINALES/OPTIMIZACION'
csvs = os.listdir(mypath)
csvs

dataframes = {}

for archivo in csvs:
    ruta_completa = os.path.join(mypath,archivo)
    nombre_df = os.path.splitext(archivo)[0]

    dataframes[nombre_df] = pd.read_csv(ruta_completa,nrows=200)
    dataframes[nombre_df]['Compresor'] = nombre_df
df_junto = pd.concat([dataframes['Comp_A'], dataframes['Comp_B'], dataframes['Comp_C'], dataframes['Comp_D']], axis=0)
df_junto.to_json('DATOS/TRANSFORMADOS/df_mosquito.json',orient='records',lines=True)
# Crear instancia al publicador 1

logging.basicConfig(level=logging.DEBUG, format='%(asctime)s > %(name)s > %(levelname)s: %(message)s')

broker = "localhost"

publisher_1 = paho.Client(paho.CallbackAPIVersion.VERSION2,"client-publish", clean_session=True)

logging.debug(f'Connecting to broker {broker}')
publisher_1.connect(broker)

topic_1 = "topic_data"

file_name = 'DATOS/TRANSFORMADOS/df_mosquito.json'
fh = open(file_name)

while True:
    for row in fh:
        data = json.loads(row)
        data['timestamp'] = str(datetime.now())
        publisher_1.publish(topic_1, json.dumps(data))
        logging.info(f"\nEnviando datos a {topic_1}: {data}")
        sleep(1)