import paho.mqtt.client as paho
import logging
from DS_functions import *

logging.basicConfig(level=logging.DEBUG, format='%(asctime)s > %(name)s > %(levelname)s: %(message)s')

topic_1 = "topic_data"
topic_2 = 'topic_queries'

handler = Handler()

# Connection
broker = "localhost"
subscriber_1 = paho.Client(paho.CallbackAPIVersion.VERSION2,"S1")
subscriber_1.on_connect = on_connect
subscriber_1.on_message = handler.on_message
logging.debug(f'Connecting to broker {broker}')

subscriber_1.connect(broker)
subscriber_1.subscribe(topic_1) 
subscriber_1.subscribe(topic_2)

logging.debug("Subscribed")
logging.debug("Start loop")
subscriber_1.loop_forever()
# Mantener el programa principal en ejecución
while True:
    # Aquí puedes colocar cualquier otra lógica que necesites ejecutar mientras el suscriptor está activo
    pass